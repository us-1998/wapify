module.exports = {
  apps: [
    {
      name: 'wapify-api',
      script: './backend/server.js',
      instances: 'max',
      exec_mode: 'cluster',
      env_file: './backend/.env',
      max_memory_restart: '512M',
      restart_delay: 3000,
      log_file: './logs/app.log',
      error_file: './logs/error.log',
      merge_logs: true,
      watch: false,
    },
  ],
};
