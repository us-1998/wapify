# Wapify — WhatsApp Business SaaS

**Production-ready WhatsApp automation platform for e-commerce stores.**
Competitor to Wati.com — built for Shopify, WooCommerce, BigCommerce.

---

## What's included

```
wapify/
├── backend/                  Node.js + Express API
│   ├── server.js             Entry point
│   ├── config/               DB, Redis, Logger, Permissions
│   ├── middleware/auth.js    JWT + RBAC
│   ├── routes/               All 14 API routes
│   └── services/             Meta WA API, Queue, Email
├── database/
│   ├── schema.sql            17 PostgreSQL tables
│   ├── migrate.js            Run schema
│   └── seed.js               Default roles + demo accounts
├── frontend/public/
│   ├── index.html            Customer SaaS app (full RBAC)
│   └── admin.html            CEO admin panel
└── ecosystem.config.js       PM2 config
```

---

## Deploy to Railway + Supabase + Vercel (FREE)

### Step 1 — Supabase database

1. Go to **supabase.com** → New project → name: `wapify`
2. **SQL Editor** → paste contents of `database/schema.sql` → Run
3. **SQL Editor** → paste contents of `database/seed.js` seed SQL → Run
4. **Settings → Database → Connection string → URI** → copy your `DATABASE_URL`

### Step 2 — Upstash Redis

1. Go to **console.upstash.com** → Create database → Regional
2. Copy **Redis URL** (looks like `redis://default:xxx@xxx.upstash.io:6379`)

### Step 3 — Push to GitHub

```bash
git init
git add .
git commit -m "Wapify initial deploy"
gh repo create wapify --private --source=. --push
```

### Step 4 — Deploy backend to Railway

1. **railway.app** → New Project → Deploy from GitHub → select `wapify`
2. **Settings → Root Directory** → set to `backend`
3. **Variables tab → Raw Editor** → paste and fill:

```
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://postgres:PASSWORD@db.PROJECT.supabase.co:5432/postgres
REDIS_URL=redis://default:PASSWORD@HOST.upstash.io:6379
JWT_SECRET=<64 random chars>
JWT_REFRESH_SECRET=<different 64 random chars>
JWT_EXPIRES_IN=15m
ADMIN_JWT_SECRET=<another 64 random chars>
ADMIN_EMAIL=admin@yourdomain.com
ADMIN_INITIAL_PASSWORD=AdminWapify@2026
META_VERIFY_TOKEN=<any random string>
EMAIL_FROM=noreply@yourdomain.com
EMAIL_FROM_NAME=Wapify
RATE_LIMIT_MAX=200
APP_URL=https://YOUR-RAILWAY-URL.up.railway.app
```

4. **Deploy** → wait 2 min → test:
```
https://YOUR-RAILWAY-URL.up.railway.app/health
```
Should return: `{"status":"ok"}`

5. **Railway shell** → run migrations:
```bash
node ../database/migrate.js
node ../database/seed.js
```

### Step 5 — Deploy frontend to Vercel

1. **vercel.com** → Import GitHub repo → Root Directory: `frontend/public`
2. Framework: **Other**
3. **Deploy** → get your Vercel URL

4. In `frontend/public/index.html` and `admin.html`, find:
```javascript
const API = window.location.hostname === 'localhost'
  ? 'http://localhost:3000/api'
  : '/api';
```
Change `/api` to `https://YOUR-RAILWAY-URL.up.railway.app/api`

5. Commit and push → Vercel auto-redeploys.

---

## Add real API keys (after deploy)

### Meta WhatsApp
1. **developers.facebook.com** → Create App → Business → WhatsApp
2. Get `META_APP_ID`, `META_APP_SECRET`
3. Meta Business Manager → System Users → create permanent token
4. Add to Railway: `META_SYSTEM_USER_TOKEN=EAAxxxxxxx`

### Stripe (billing)
1. **stripe.com** → Developers → API Keys → copy `sk_live_...`
2. Create Products + Prices for Growth/Scale/Agency plans
3. Webhooks → add endpoint: `https://YOUR-RAILWAY.up.railway.app/api/billing/webhook`
4. Add to Railway:
```
STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
STRIPE_PRICE_GROWTH_MONTHLY=price_xxx
STRIPE_PRICE_SCALE_MONTHLY=price_xxx
STRIPE_PRICE_AGENCY_MONTHLY=price_xxx
```

### Email (Brevo - 300/day free)
1. **brevo.com** → Sign up → Settings → SMTP & API → SMTP
2. Add to Railway:
```
SMTP_HOST=smtp-relay.brevo.com
SMTP_PORT=587
SMTP_USER=your@email.com
SMTP_PASS=your_smtp_key
```

### Shopify (for OAuth)
1. **partners.shopify.com** → Create app
2. App URL: `https://YOUR-RAILWAY.up.railway.app`
3. Redirect URL: `https://YOUR-RAILWAY.up.railway.app/api/stores/shopify/callback`
4. Add to Railway:
```
SHOPIFY_API_KEY=xxx
SHOPIFY_API_SECRET=xxx
SHOPIFY_SCOPES=read_orders,read_products,read_customers,write_orders
```

After adding keys → Railway → Redeploy.

---

## Default login credentials

| Type | Email | Password |
|------|-------|----------|
| Customer app | demo@wapify.com | Demo@123456 |
| Admin panel | admin@wapify.com | AdminWapify@2026 |

**Change these immediately after first login.**

---

## Role-Based Access Control

| Role | Access |
|------|--------|
| **Owner** | Everything |
| **Admin** | Everything except delete/billing manage |
| **Marketing** | Flows, templates, broadcasts, catalogue |
| **Sales** | Orders, conversations, analytics |
| **Support** | Conversations + orders only |

Custom roles can be created with any permission combination.

---

## Local development

```bash
# Install dependencies
cd backend && npm install

# Create .env from example
cp .env.example .env
# Fill in DATABASE_URL and REDIS_URL

# Run migrations
node ../database/migrate.js
node ../database/seed.js

# Start server
npm run dev
```

Open `frontend/public/index.html` in browser (or serve with any static server).

---

## API health check

```
GET /health
```
Returns database + version status.

---

## Key commands

```bash
# View logs
pm2 logs wapify-api

# Restart after .env changes
pm2 restart all

# Database backup
pg_dump $DATABASE_URL > backup.sql
```
